import UIKit

//Función que recibe un argumento y retorna un número real
func perimetro(radio: Double) -> Double {
    let PI = 3.14159
    
    return 2 * PI * radio
}

var per:Double = 0

per = perimetro(radio: 10.0)
print("Perímetro: \(per)")


var area:Double = 0

//Función que recibe un argumento y retorna un número real
func circunferencia(radio: Double) -> (perimetro: Double, area: Double) {
    let PI = 3.14159

    //https://www.dotnetperls.com/math-swift
    return (2 * PI * radio, PI * pow(radio, 2))
}

per = circunferencia(radio: 5.0).perimetro
print("Perímetro: \(per)")
area = circunferencia(radio: 5.0).area
print("Área: \(area)")

