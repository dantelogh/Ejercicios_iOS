//Ejemplos 01

import UIKit

//Para crear variables "var"
var str = "Hello, World!"
//Para crear constantes "let"
let pi = 3.14159
let radio: Double = 10.5

print(str)
print("La constante es: \(pi)")
print("El perímetro es: \(2 * pi * radio)")


//Bucle for
var total = 0

for i in 0...10 {
    total += i
}
//print("Iteraciones: \(i)")
print("Total: \(total)")


//Uso de arrays
//let notas = [7, 3, 0, 2, 1, 4, 10, 5, 6, 4]
var notas = [7, 3, 0, 2, 1, 4, 10, 5, 6, 4]
var aprobados = 0
var suspendidos = 0

//Bucle for-each y estructura if-else
for nota in notas {
    if nota >= 5 {
        aprobados += 1
    }
    else {
        suspendidos += 1
    }
}
print("Total aprobados: \(aprobados)")
print("Total suspendidos: \(suspendidos)")
print("Nota del 3 alumno: \(notas[2])")

//Añadir elementos al array
notas.append(9)
print("Nota del nuevo alumno: \(notas[notas.count - 1])")

//Estructura switch-case
let opcion:Int = 1

switch opcion {
case 1:
    print("Opción de Menú 1")
case 2:
    print("Opción de Menú 2")
default:
    print("¡Error!")
}
